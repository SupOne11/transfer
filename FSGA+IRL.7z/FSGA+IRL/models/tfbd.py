# Copyright (c) 2022, Zikang Zhou. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import pytorch_lightning as pl
import torch
import torch.nn as nn
import torch.nn.functional as F

from losses import LaplaceNLLLoss
from losses import SoftTargetCrossEntropyLoss
from metrics import ADE, FDE, MR, FDE_one_stage, MR_one_stage
from models import HiVT
from models import FutureEncoder, FutDecoder
from utils import TemporalData, rotate_and_translate

from models import MLPDecoder
from models import ScoreDecoder


class TFBD(pl.LightningModule):

    def __init__(self,
                 historical_steps: int,
                 future_steps: int,
                 num_modes: int,
                 num_mid: int,
                 rotate: bool,
                 node_dim: int,
                 edge_dim: int,
                 embed_dim: int,
                 num_heads: int,
                 dropout: float,
                 num_temporal_layers: int,
                 num_global_layers: int,
                 local_radius: float,
                 parallel: bool,
                 lr: float,
                 weight_decay: float,
                 T_max: int,
                 pretrained: bool,
                 ckpt_path: str,
                 save_path: str,
                 val: str,
                 plot: bool,
                 stage: str,
                 center_node_dim: int,
                 single_node_dim: int,
                 **kwargs) -> None:
        super(TFBD, self).__init__()
        self.save_hyperparameters()
        self.historical_steps = historical_steps
        self.future_steps = future_steps
        self.num_modes = num_modes
        self.num_mid = num_mid
        self.embed_dim = embed_dim
        self.rotate = rotate
        self.parallel = parallel
        self.lr = lr
        self.weight_decay = weight_decay
        self.T_max = T_max

        self.backbone = HiVT(historical_steps=historical_steps,
                             future_steps=future_steps,
                             num_modes=num_modes,
                             rotate=rotate,
                             center_node_dim=center_node_dim,
                             single_node_dim=single_node_dim,
                             node_dim=node_dim,
                             edge_dim=edge_dim,
                             embed_dim=embed_dim,
                             num_heads=num_heads,
                             dropout=dropout,
                             num_temporal_layers=num_temporal_layers,
                             num_global_layers=num_global_layers,
                             local_radius=local_radius,
                             parallel=parallel,
                             lr=lr,
                             weight_decay=weight_decay,
                             T_max=T_max)
        self.decoder = MLPDecoder(local_channels=embed_dim,
                                  global_channels=embed_dim,
                                  future_steps=future_steps,
                                  num_modes=num_modes,
                                  uncertain=True)
        self.future_encoder = FutureEncoder(node_dim=node_dim,
                                            edge_dim=edge_dim,
                                            embed_dim=embed_dim,
                                            num_heads=num_heads,
                                            dropout=dropout,
                                            local_radius=local_radius)
        self.future_decoder = FutDecoder(local_channels=embed_dim,
                                         global_channels=embed_dim,
                                         future_channels=embed_dim,
                                         future_steps=future_steps,
                                         num_modes=num_modes,
                                         uncertain=True)
        self.score = ScoreDecoder(variable_cost=True)

        self.reg_loss = LaplaceNLLLoss(reduction='mean')
        self.cls_loss = SoftTargetCrossEntropyLoss(reduction='mean')

        self.minADE = ADE()
        self.minFDE = FDE()
        self.minMR = MR()
        self.minFDE_one_stage = FDE_one_stage()
        self.minMR_one_stage = MR_one_stage()

        self.save_path = save_path
        self.stage = stage
        if val == 'val':
            self.val = True
        else:
            self.val = False
        self.plot = plot
        if pretrained:
            #   pretrained_dict = torch.load(ckpt_path)
            #   backbone_dict = self.backbone.state_dict()
            #   backbone_pretrained = {k: v for k, v in pretrained_dict['state_dict'].items() if (k in backbone_dict)}
            #   backbone_dict.update(backbone_pretrained)
            for param in self.backbone.parameters():
                param.requires_grad = False
            #    decoder_dict = self.decoder.state_dict()
            #    decoder_pretrained = {k: v for k, v in pretrained_dict['state_dict'].items()
            #                          if (k in decoder_dict)}
            #    decoder_dict.update(decoder_pretrained)
            for param in self.decoder.parameters():
                param.requires_grad = False

    def forward(self, data: TemporalData):
        if self.rotate:
            rotate_mat = torch.empty(data.num_nodes, 2, 2, device=self.device)
            sin_vals = torch.sin(data['rotate_angles'])
            cos_vals = torch.cos(data['rotate_angles'])
            rotate_mat[:, 0, 0] = cos_vals
            rotate_mat[:, 0, 1] = -sin_vals
            rotate_mat[:, 1, 0] = sin_vals
            rotate_mat[:, 1, 1] = cos_vals
            rotate_mat_all = torch.empty(data.num_nodes, 20, 2, 2, device=self.device)
            rotate_mat_all[:, :, 0, 0] = data['alpha_value'][:, :, 0]
            rotate_mat_all[:, :, 0, 1] = -data['alpha_value'][:, :, 1]
            rotate_mat_all[:, :, 1, 0] = data['alpha_value'][:, :, 1]  # rotate_mat_all代表agent车所有时间戳下的heading角旋转矩阵，av坐标系下
            rotate_mat_all[:, :, 1, 1] = data['alpha_value'][:, :, 0]  # 第一个时间戳的旋转矩阵暂时都设置为0
            if data.y is not None:
                data.y = torch.bmm(data.y, rotate_mat)  # 经过这步旋转，y就变成了以中心actor为原点,heading为x轴坐标系下的坐标值
            data['rotate_mat'] = rotate_mat  # 根据每个actor在av坐标系下的heading角作的旋转矩阵
            data['rotate_mat_all'] = rotate_mat_all
        else:
            data['rotate_mat'] = None
            data['rotate_mat_all'] = None
        local_embed, global_embed = self.backbone(data)  # [B, N, D]
        g_pre = self.decoder(local_embed=local_embed, global_embed=global_embed)
        if self.stage == 'one':
            return g_pre
        # 将初步预测轨迹转移到av坐标系内
        pm = rotate_and_translate(g_pre['pm'][:, :2].view(-1, 1, 1, 2), -data['rotate_angles'],
                                  data['positions'][:, 19, :]).squeeze().detach()  # [N, mod-mid, 2]
        pf = rotate_and_translate(g_pre['pf'][:, :2].view(-1, 1, 1, 2), -data['rotate_angles'],
                                  data['positions'][:, 19, :]).squeeze().detach()  # [N, mod-end, 2]
        # 构造中点a-l图，进行GAT特征融合
        mid_embed = torch.zeros([data['num_nodes'], self.embed_dim], device=self.device)
        lane_start, lane_end, car_start, car_end = 0, 0, 0, 0
        hi, wi = [], []
        p = pm.squeeze()  # [N, 2]一个batch全部的预测中点
        lane_center = data['lane_center'][:, :2]
        for i in range(data['lane_num'].size(0)):
            lane_end += data['lane_num'][i]  # 通过start和end索引出一个数据的车道节点
            car_end += data['car_num'][i]
            lane = lane_center[lane_start: lane_end]
            traj = p[car_start: car_end, :]
            dist = lane.view(-1, 1, 2) - traj.view(1, -1, 2)
            dist = torch.sqrt((dist ** 2).sum(2))
            mask = dist <= 20
            idcs = torch.nonzero(mask, as_tuple=False)
            if len(idcs) == 0:
                continue
            hi.append(idcs[:, 0] + lane_start)
            wi.append(idcs[:, 1] + car_start)
            lane_start += data['lane_num'][i]
            car_start += data['car_num'][i]
        hi = torch.cat(hi, 0)
        wi = torch.cat(wi, 0)
        mid_edge_ind = torch.vstack((hi, wi))
        mid_edge_attr = lane_center[hi] - p[wi, :]
        mid_embed = self.future_encoder(data=data, lane_actor_index_future=mid_edge_ind,
                                        lane_actor_vectors_future=mid_edge_attr, x=global_embed)
        # 构造终点a-l图，进行GAT特征融合
        end_embed = torch.zeros([self.embed_dim], device=self.device)
        lane_start, lane_end, car_start, car_end = 0, 0, 0, 0
        hi, wi = [], []
        p = pf.squeeze()  # [N, 2]某个模态下一个batch全部的预测终点
        for i in range(data['lane_num'].size(0)):
            lane_end += data['lane_num'][i]  # 通过start和end索引出一个数据的车道节点
            car_end += data['car_num'][i]
            lane = lane_center[lane_start: lane_end]
            traj = p[car_start:car_end, :]
            dist = lane.view(-1, 1, 2) - traj.view(1, -1, 2)
            dist = torch.sqrt((dist ** 2).sum(2))
            mask = dist <= 20
            idcs = torch.nonzero(mask, as_tuple=False)
            if len(idcs) == 0:
                continue
            hi.append(idcs[:, 0] + lane_start)
            wi.append(idcs[:, 1] + car_start)
            lane_start += data['lane_num'][i]
            car_start += data['car_num'][i]
        hi = torch.cat(hi, 0)
        wi = torch.cat(wi, 0)
        end_edge_ind = torch.vstack((hi, wi))
        end_edge_attr = lane_center[hi] - p[wi, :]
        end_embed = self.future_encoder(data=data, lane_actor_index_future=end_edge_ind,
                                        lane_actor_vectors_future=end_edge_attr, x=mid_embed)
        all_indices = torch.arange(local_embed.size(0), device=data['av_index'].device)
        agent_index = ~torch.isin(all_indices, data['av_index'])
        y_av, y_agent = self.future_decoder(global_embed, mid_embed, end_embed, data['av_index'], agent_index)
        y_agent_ = rotate_and_translate(y_agent[:, :, :2].view(-1, 1, self.future_steps, 2),
                                        -data['rotate_angles'][agent_index],
                                        data['positions'][agent_index, 19, :]).squeeze()  # [N, 80, 2]
        pi, _ = self.score(y_av[:, :, :, :2], global_embed[data['av_index']], y_agent_[:, :, :2], data, agent_index)
        return y_av, y_agent, pi, g_pre

    def training_step(self, data, batch_idx):
        if self.stage == 'two':
            y_av_hat, y_agent_hat, pi, p = self(data)
            y_av = data.y[data['av_index']]
            all_indices = torch.arange(data['batch'].size(0), device=data['batch'].device)
            agent_index = ~torch.isin(all_indices, data['av_index'])
            y_agent = data.y[agent_index]
            reg_mask = ~data['padding_mask'][:, self.historical_steps:]  # [N, H]未来每一个时刻交通参与者是否存在的掩码
            reg_av = reg_mask[data['av_index']]
            reg_agent = reg_mask[agent_index]
            # calculate motion prediction loss
            l2_norm = (torch.norm(y_av_hat[:, :, :, : 2] - y_av, p=2, dim=-1) * reg_av).sum(dim=-1)  # [F, 1]自车预测轨迹总误差
            best_mode = l2_norm.argmin(dim=0)  # [1] 预测总误差最小的模态的索引
            y_av_best = y_av_hat[best_mode, torch.arange(data.num_graphs)]
            reg_loss = 0.7 * self.reg_loss(y_av_best, y_av) + 0.3 * self.reg_loss(y_agent_hat[reg_agent],
                                                                                  y_agent[reg_agent])
            soft_target = F.softmax(-l2_norm[:, :] / self.future_steps, dim=0).t().detach()  # 根据平均误差计算评分
            cls_loss = self.cls_loss(pi, soft_target)  # 期望轨迹置信度与轨迹平均误差成反比
        else:
            reg_loss = 0
            cls_loss = 0
            p = self(data)
        # calculate goal prediction loss
        pm, pf = p['pm'], p['pf']
        mid_ind = int(self.historical_steps + self.future_steps / 2 - 1)
        end_ind = int(self.historical_steps + self.future_steps - 1)
        mid_mask = ~data['padding_mask'][:, mid_ind]
        reg_mid = self.reg_loss(pm[mid_mask], data.y[mid_mask, mid_ind - self.historical_steps])
        end_mask = ~data['padding_mask'][:, end_ind]
        reg_end = self.reg_loss(pf[end_mask], data.y[end_mask, end_ind - self.historical_steps])
        loss_pre = reg_mid + reg_end
        if self.stage == 'two':
            loss = 0.7 * (reg_loss + cls_loss) + 0.3 * loss_pre
        else:
            loss = loss_pre
        self.log('train_reg_loss', reg_loss, prog_bar=True, on_step=True, on_epoch=True, batch_size=1)
        self.log('loss', loss, prog_bar=True, on_step=True, on_epoch=True, batch_size=1)
        return loss

    def validation_step(self, data, batch_idx):
        if self.stage == 'two':
            y_av, _, _, p = self(data)

            y_av = y_av[:, :, :, : 2]
            y = data.y[data['av_index']]
            fde_av = torch.norm(y_av[:, :, -1] - y[:, -1], p=2, dim=-1)
            best_mode_av = fde_av.argmin(dim=0)
            y_av_best = y_av[best_mode_av, torch.arange(data.num_graphs)]
            self.minADE.update(y_av_best, y)
            self.minFDE.update(y_av_best, y)
            self.minMR.update(y_av_best, y)
            self.log('val_minADE', self.minADE, prog_bar=True, on_step=False, on_epoch=True, batch_size=data.num_graphs)
            self.log('val_minFDE', self.minFDE, prog_bar=True, on_step=False, on_epoch=True, batch_size=data.num_graphs)
            self.log('val_minMR', self.minMR, prog_bar=True, on_step=False, on_epoch=True, batch_size=data.num_graphs)
            reg_loss = self.reg_loss(y_av_best, y)
            self.log('val_reg_loss', reg_loss, prog_bar=True, on_step=False, on_epoch=True, batch_size=1)
        else:
            y_pre = self(data)
            pf = y_pre['pf']
            end_ind = int(self.historical_steps + self.future_steps - 1)
            end_mask = ~data['padding_mask'][:, end_ind]
            reg_end = self.reg_loss(pf[end_mask, :2], data.y[end_mask, end_ind - self.historical_steps])
            self.log('val_reg_loss', reg_end, prog_bar=True, on_step=True, on_epoch=True, batch_size=1)

            y_hat_agent = pf[data['av_index'], : 2]
            y_agent = data.y[data['av_index'], -1]
            self.minFDE_one_stage.update(y_hat_agent, y_agent)
            self.minMR_one_stage.update(y_hat_agent, y_agent)
            self.log('val_minFDE', self.minFDE_one_stage, prog_bar=True, on_step=False, on_epoch=True,
                     batch_size=y_agent.size(0))
            self.log('val_minMR', self.minMR_one_stage, prog_bar=True, on_step=False, on_epoch=True,
                     batch_size=y_agent.size(0))

    def configure_optimizers(self):
        decay = set()
        no_decay = set()
        whitelist_weight_modules = (nn.Linear, nn.Conv1d, nn.Conv2d, nn.Conv3d, nn.MultiheadAttention, nn.LSTM, nn.GRU)
        blacklist_weight_modules = (nn.BatchNorm1d, nn.BatchNorm2d, nn.BatchNorm3d, nn.LayerNorm, nn.Embedding)
        for module_name, module in self.named_modules():
            for param_name, param in module.named_parameters():
                full_param_name = '%s.%s' % (module_name, param_name) if module_name else param_name
                if 'bias' in param_name:
                    no_decay.add(full_param_name)
                elif 'weight' in param_name:
                    if isinstance(module, whitelist_weight_modules):
                        decay.add(full_param_name)
                    elif isinstance(module, blacklist_weight_modules):
                        no_decay.add(full_param_name)
                elif not ('weight' in param_name or 'bias' in param_name):
                    no_decay.add(full_param_name)
        param_dict = {param_name: param for param_name, param in self.named_parameters()}
        inter_params = decay & no_decay
        union_params = decay | no_decay
        assert len(inter_params) == 0
        assert len(param_dict.keys() - union_params) == 0

        optim_groups = [
            {"params": [param_dict[param_name] for param_name in sorted(list(decay))],
             "weight_decay": self.weight_decay},
            {"params": [param_dict[param_name] for param_name in sorted(list(no_decay))],
             "weight_decay": 0.0},
        ]

        optimizer = torch.optim.AdamW(optim_groups, lr=self.lr, weight_decay=self.weight_decay)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer=optimizer, T_max=self.T_max, eta_min=0.0)
        return [optimizer], [scheduler]

    @staticmethod
    def add_model_specific_args(parent_parser):
        parser = parent_parser.add_argument_group('TfBD')
        parser.add_argument('--historical_steps', type=int, default=20)
        parser.add_argument('--future_steps', type=int, default=80)
        parser.add_argument('--num_modes', type=int, default=6)
        parser.add_argument('--num_mid', type=int, default=3)
        parser.add_argument('--rotate', type=bool, default=True)
        parser.add_argument('--center_node_dim', type=int, default=7)
        parser.add_argument('--single_node_dim', type=int, default=1)
        parser.add_argument('--node_dim', type=int, default=2)
        parser.add_argument('--edge_dim', type=int, default=2)
        parser.add_argument('--embed_dim', type=int, default=128)
        parser.add_argument('--num_heads', type=int, default=8)
        parser.add_argument('--dropout', type=float, default=0.1)
        parser.add_argument('--num_temporal_layers', type=int, default=4)
        parser.add_argument('--num_global_layers', type=int, default=3)
        parser.add_argument('--local_radius', type=float, default=50)

        return parent_parser
