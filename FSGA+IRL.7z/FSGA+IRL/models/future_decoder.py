# Copyright (c) 2022, Zikang Zhou. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from typing import Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

from utils import init_weights


class FutDecoder(nn.Module):
    def __init__(self,
                 local_channels: int,
                 global_channels: int,
                 future_channels: int,
                 future_steps: int,
                 num_modes: int,
                 uncertain: bool = True,
                 min_scale: float = 1e-3) -> None:
        super(FutDecoder, self).__init__()
        self.input_size = global_channels
        self.hidden_size = local_channels
        self.future_size = future_channels
        self.future_steps = future_steps
        self.num_modes = num_modes
        self.uncertain = uncertain
        self.min_scale = min_scale

        self.aggr_embed = nn.Sequential(
            nn.Linear(self.input_size + self.hidden_size + self.future_size, self.hidden_size),
            nn.LayerNorm(self.hidden_size),
            nn.ReLU(inplace=True))
        self.multi_head = nn.Linear(self.input_size, 6 * self.input_size)
        self.single_head = nn.Linear(self.input_size, self.input_size)
        self.loc = nn.Sequential(
            nn.Linear(self.hidden_size, self.hidden_size),
            nn.LayerNorm(self.hidden_size),
            nn.ReLU(inplace=True),
            nn.Linear(self.hidden_size, self.future_steps * 2))
        if uncertain:
            self.scale = nn.Sequential(
                nn.Linear(self.hidden_size, self.hidden_size),
                nn.LayerNorm(self.hidden_size),
                nn.ReLU(inplace=True),
                nn.Linear(self.hidden_size, self.future_steps * 2))
        self.apply(init_weights)

    def forward(self,
                local_embed: torch.Tensor,
                mid_embed: torch.Tensor,
                end_embed: torch.Tensor,
                av_index: torch.Tensor,
                agent_index):

        out = self.aggr_embed(torch.cat((local_embed, mid_embed, end_embed), dim=-1))
        av = self.multi_head(out[av_index]).view(-1, 6, self.input_size)
        agent = self.single_head(out[agent_index])
        loc_av = self.loc(av.transpose(0, 1)).view(self.num_modes, -1, self.future_steps, 2)  # [F, N, H, 2]
        loc_agent = self.loc(agent).view(-1, self.future_steps, 2)                            # [N, H, 2]
        if self.uncertain:
            scale_av = F.elu_(self.scale(av), alpha=1.0).view(self.num_modes, -1, self.future_steps, 2) + 1.0
            scale_av = scale_av + self.min_scale  # [F, N, H, 2]
            scale_agent = F.elu_(self.scale(agent), alpha=1.0).view(-1, self.future_steps, 2) + 1.0
            scale_agent = scale_agent + self.min_scale  # [F, N, H, 2]
            return torch.cat((loc_av, scale_av), dim=-1), torch.cat((loc_agent, scale_agent), dim=-1)   # [F, N, H, 4], [N, F], [N, H, 4]
        else:
            return loc_av, loc_agent    # [F, N, H, 2], [N, F]
