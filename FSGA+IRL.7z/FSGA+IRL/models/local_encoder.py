# Copyright (c) 2022, Zikang Zhou. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.data import Batch
from torch_geometric.data import Data
from torch_geometric.nn.conv import MessagePassing
from torch_geometric.typing import Adj
from torch_geometric.typing import OptTensor
from torch_geometric.typing import Size
from torch_geometric.utils import softmax
from torch_geometric.utils import subgraph
from torch_scatter import scatter, segment_csr
# from torch_geometric.nn.conv.utils.helpers import expand_left
from models import MultipleInputEmbedding, PointsEncoder, LaneEmbedding
from models import SingleInputEmbedding
from utils import DistanceDropEdge
from utils import TemporalData
from utils import init_weights
from models.transformer_encoder import TransformerEncoder


class LocalEncoder(nn.Module):

    def __init__(self,
                 historical_steps: int,
                 node_dim: int,
                 center_node_dim: int,
                 single_node_dim: int,
                 edge_dim: int,
                 embed_dim: int,
                 num_heads: int = 8,
                 dropout: float = 0.1,
                 num_temporal_layers: int = 4,
                 local_radius: float = 50,
                 parallel: bool = False) -> None:
        super(LocalEncoder, self).__init__()
        self.historical_steps = historical_steps
        self.parallel = parallel

        self.drop_edge_AA1 = DistanceDropEdge(local_radius)
        self.drop_edge_AL1 = DistanceDropEdge(max_distance=10)
        self.drop_edge_AL2 = DistanceDropEdge(local_radius)
        self.aa1_encoder = AA1Encoder(historical_steps=historical_steps,
                                      node_dim=node_dim,
                                      center_node_dim=center_node_dim,
                                      edge_dim=edge_dim,
                                      embed_dim=embed_dim,
                                      num_heads=num_heads,
                                      dropout=dropout,
                                      parallel=parallel)
        self.temporal_encoder_aa2 = TemporalEncoder(historical_steps=historical_steps,
                                                    embed_dim=embed_dim,
                                                    num_heads=num_heads,
                                                    dropout=dropout,
                                                    num_layers=num_temporal_layers)
        self.al_encoder = ALEncoder(node_dim=node_dim,
                                    edge_dim=edge_dim,
                                    embed_dim=embed_dim,
                                    num_heads=num_heads,
                                    dropout=dropout)

        self.al1_encoder = ALEncoder(node_dim=node_dim,
                                     edge_dim=edge_dim,
                                     embed_dim=embed_dim,
                                     num_heads=num_heads,
                                     dropout=dropout)

    def forward(self, data: TemporalData) -> torch.Tensor:
        for t in range(self.historical_steps):
            if data.edge_index.size(0) > 0:
                data[f'edge_index_{t}'], _ = subgraph(subset=~data['padding_mask'][:, t], edge_index=data.edge_index)
                data[f'edge_attr_{t}'] = \
                    data['positions'][data[f'edge_index_{t}'][0], t] - data['positions'][data[f'edge_index_{t}'][1], t]
                data[f'edge_v_attr_{t}'] = \
                    data['v'][data[f'edge_index_{t}'][0], t] - data['v'][data[f'edge_index_{t}'][1], t]
                data[f'edge_heading_attr_{t}'] = \
                    torch.stack([torch.cos(data['alpha'][data[f'edge_index_{t}'][1], t]
                                           - data['alpha'][data[f'edge_index_{t}'][0], t]),
                                 torch.sin(data['alpha'][data[f'edge_index_{t}'][1], t]
                                           - data['alpha'][data[f'edge_index_{t}'][0], t])], dim=1)
            else:
                # 设置空的Tensor以符合之后的操作要求
                empty_index = torch.empty((2, 0), dtype=torch.long, device=data.edge_index.device)
                data[f'edge_index_{t}'] = empty_index
                data[f'edge_attr_{t}'] = torch.empty((0, 2), device=data.edge_index.device)
                data[f'edge_v_attr_{t}'] = torch.empty((0, 2), device=data.edge_index.device)
                data[f'edge_heading_attr_{t}'] = torch.empty((0, 2), device=data.edge_index.device)

        out = [None] * self.historical_steps
        for t in range(self.historical_steps):
            edge_index, edge_attr, edge_v_attr, edge_heading_attr = self.drop_edge_AA1(data[f'edge_index_{t}'],
                                                                                       data[f'edge_attr_{t}'],
                                                                                       data[f'edge_v_attr_{t}'],
                                                                                       data[f'edge_heading_attr_{t}'])
            aa1_res, _ = self.aa1_encoder(x=data.x[:, t], v=data['v'][:, t],
                                          alpha_value=data['alpha_value'][:, t],
                                          v_abs=data['v_abs'][:, t], t=t,
                                          edge_index=edge_index,
                                          edge_attr=edge_attr,
                                          edge_v_attr=edge_v_attr,
                                          edge_heading_attr=edge_heading_attr,
                                          cls=data['cls'],
                                          shape=data['shape'],
                                          bos_mask=data['bos_mask'][:, t],
                                          rotate_mat=data['rotate_mat'],
                                          rotate_mat_cur=data['rotate_mat_all'][:, t])  # 当前时间戳的旋转矩阵
            out[t] = aa1_res
        out = torch.stack(out)  # [T, N, D]
        out = self.temporal_encoder_aa2(x=out, padding_mask=data['padding_mask'][:, : self.historical_steps])
        edge_index, edge_attr = self.drop_edge_AL2(data['lane_actor_index'], data['lane_actor_vectors'])

        out = self.al_encoder(x=(data['lane_vectors'], out),
                              edge_index=edge_index,
                              edge_attr=edge_attr,
                              positions=data['positions'][:, 19],
                              lane_positions=data['lane_positions'],
                              lane_types=data['lane_types'],
                              lane_on_route=data['lane_on_route'],
                              lane_tl_status=data['lane_tl_status'],
                              lane_has_speed_limit=data['lane_has_speed_limit'],
                              lane_speed_limit=data['lane_speed_limit'],
                              lane_valid_mask=data['lane_valid_mask'],
                              rotate_mat=data['rotate_mat'],
                              av_index=data['av_index'])
        return out


class AA1Encoder(MessagePassing):

    def __init__(self,
                 historical_steps: int,
                 node_dim: int,
                 center_node_dim: int,
                 edge_dim: int,
                 embed_dim: int,
                 num_heads: int = 8,
                 dropout: float = 0.1,
                 parallel: bool = False,
                 shape_dim: int = 2,
                 **kwargs) -> None:
        super(AA1Encoder, self).__init__(aggr='add', node_dim=0, **kwargs)
        self.historical_steps = historical_steps
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.parallel = parallel

        self.center_embed = MultipleInputEmbedding(in_channels=[center_node_dim, shape_dim], out_channel=embed_dim)
        self.nbr_embed = MultipleInputEmbedding(in_channels=[node_dim, edge_dim, edge_dim, edge_dim, edge_dim,
                                                edge_dim, edge_dim, shape_dim], out_channel=embed_dim)
        self.lin_q = nn.Linear(embed_dim, embed_dim)
        self.lin_k = nn.Linear(embed_dim, embed_dim)
        self.lin_v = nn.Linear(embed_dim, embed_dim)
        self.lin_self = nn.Linear(embed_dim, embed_dim)
        self.attn_drop = nn.Dropout(dropout)
        self.lin_ih = nn.Linear(embed_dim, embed_dim)
        self.lin_hh = nn.Linear(embed_dim, embed_dim)
        self.out_proj = nn.Linear(embed_dim, embed_dim)
        self.proj_drop = nn.Dropout(dropout)
        self.norm1 = nn.LayerNorm(embed_dim)
        self.norm2 = nn.LayerNorm(embed_dim)
        self.mlp = nn.Sequential(
            nn.Linear(embed_dim, embed_dim * 4),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(embed_dim * 4, embed_dim),
            nn.Dropout(dropout))
        self.bos_token = nn.Parameter(torch.Tensor(historical_steps, embed_dim))
        nn.init.normal_(self.bos_token, mean=0., std=.02)
        self.cls_embed = nn.Parameter(torch.Tensor(4, embed_dim))
        nn.init.normal_(self.cls_embed, mean=0., std=.02)
        self.apply(init_weights)

    def forward(self,
                x: torch.Tensor,
                v: torch.Tensor,
                alpha_value: torch.Tensor,
                v_abs: torch.Tensor,
                t: Optional[int],
                edge_index: Adj,
                edge_attr: torch.Tensor,
                edge_v_attr: torch.Tensor,
                edge_heading_attr: torch.Tensor,
                cls: torch.Tensor,
                shape: torch.Tensor,
                bos_mask: torch.Tensor,
                rotate_mat: Optional[torch.Tensor] = None,
                rotate_mat_cur: Optional[torch.Tensor] = None,
                size: Size = None) -> Tuple[torch.Tensor, torch.Tensor]:
        cls = cls.long()
        x_rotate = torch.bmm(x.unsqueeze(-2), rotate_mat).squeeze(-2)
        v_rotate = torch.bmm(v.unsqueeze(-2), rotate_mat).squeeze(-2)
        alpha_value_rotate = torch.bmm(alpha_value.unsqueeze(-2), rotate_mat).squeeze(-2)
        feature = torch.cat((x_rotate, v_rotate, alpha_value_rotate, v_abs.unsqueeze(-1)),
                            dim=-1)
        center_embed = self.center_embed([feature, shape], [self.cls_embed[cls]])
        center_embed = torch.where(bos_mask.unsqueeze(-1), self.bos_token[t], center_embed)
        mha_block_res, nbr_embed = self._mha_block(self.norm1(center_embed), x, edge_index, edge_attr, edge_v_attr,
                                                   edge_heading_attr, cls, shape, rotate_mat, rotate_mat_cur,
                                                   size)
        center_embed = center_embed + mha_block_res
        center_embed = center_embed + self._ff_block(self.norm2(center_embed))
        return center_embed, nbr_embed

    def message(self,
                edge_index: Adj,
                center_embed_i: torch.Tensor,
                x_j: torch.Tensor,
                edge_attr: torch.Tensor,
                edge_v_attr: torch.Tensor,
                edge_heading_attr: torch.Tensor,
                cls_j: torch.Tensor,
                shape_j: torch.Tensor,
                rotate_mat_cur: Optional[torch.Tensor],
                rotate_mat: Optional[torch.Tensor],
                index: torch.Tensor,
                ptr: OptTensor,
                size_i: Optional[int]) -> Tuple[torch.Tensor, torch.Tensor]:
        center_rotate_mat = rotate_mat[edge_index[1]]
        center_rotate_mat_cur = rotate_mat_cur[edge_index[1]]
        rel_value = torch.stack([torch.norm(edge_attr, dim=-1), torch.norm(edge_v_attr, dim=-1)], dim=1)

        nbr_embed = self.nbr_embed([torch.bmm(x_j.unsqueeze(-2), center_rotate_mat).squeeze(-2),
                                    torch.bmm(edge_attr.unsqueeze(-2), center_rotate_mat).squeeze(-2),
                                    torch.bmm(edge_v_attr.unsqueeze(-2), center_rotate_mat).squeeze(-2),
                                    rel_value,
                                    torch.bmm(-edge_attr.unsqueeze(-2), center_rotate_mat_cur).squeeze(-2),
                                    torch.bmm(-edge_v_attr.unsqueeze(-2), center_rotate_mat_cur).squeeze(-2),
                                    edge_heading_attr, shape_j], [self.cls_embed[cls_j]])
        query = self.lin_q(center_embed_i).view(-1, self.num_heads, self.embed_dim // self.num_heads)
        key = self.lin_k(nbr_embed).view(-1, self.num_heads, self.embed_dim // self.num_heads)
        value = self.lin_v(nbr_embed).view(-1, self.num_heads, self.embed_dim // self.num_heads)
        scale = (self.embed_dim // self.num_heads) ** 0.5
        alpha = (query * key).sum(dim=-1) / scale
        alpha = softmax(alpha, index, ptr, size_i)
        alpha = self.attn_drop(alpha)
        return value * alpha.unsqueeze(-1), nbr_embed

    def aggregate(self, inputs: torch.Tensor, index: torch.Tensor,
                  ptr: Optional[torch.Tensor] = None,
                  dim_size: Optional[int] = None) -> Tuple[torch.Tensor, torch.Tensor]:
        r"""Aggregates messages from neighbors as
        :math:`\square_{j \in \mathcal{N}(i)}`.

        Takes in the output of message computation as first argument and any
        argument which was initially passed to :meth:`propagate`.

        By default, this function will delegate its call to scatter functions
        that support "add", "mean" and "max" operations as specified in
        :meth:`__init__` by the :obj:`aggr` argument.
        """
        agg_inputs, nbr_embed = inputs
        if ptr is not None:
            ptr = self.expand_left(ptr, dim=self.node_dim, dims=agg_inputs.dim())
            return segment_csr(agg_inputs, ptr, reduce=self.aggr), nbr_embed
        else:
            return scatter(agg_inputs, index, dim=self.node_dim, dim_size=dim_size,
                           reduce=self.aggr), nbr_embed

    def update(self,
               inputs: torch.Tensor,
               center_embed: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        upd_inputs, nbr_embed = inputs
        upd_inputs = upd_inputs.view(-1, self.embed_dim)
        gate = torch.sigmoid(self.lin_ih(upd_inputs) + self.lin_hh(center_embed))
        return upd_inputs + gate * (self.lin_self(center_embed) - upd_inputs), nbr_embed

    def _mha_block(self,
                   center_embed: torch.Tensor,
                   x: torch.Tensor,
                   edge_index: Adj,
                   edge_attr: torch.Tensor,
                   edge_v_attr: torch.Tensor,
                   edge_heading_attr: torch.Tensor,
                   cls: torch.Tensor,
                   shape: torch.Tensor,
                   rotate_mat: Optional[torch.Tensor],
                   rotate_mat_cur: Optional[torch.Tensor],
                   size: Size) -> Tuple[torch.Tensor, torch.Tensor]:
        propagate_res, nbr_embed = self.propagate(edge_index=edge_index, x=x, center_embed=center_embed,
                                                  edge_attr=edge_attr, edge_v_attr=edge_v_attr,
                                                  edge_heading_attr=edge_heading_attr, cls=cls, shape=shape,
                                                  rotate_mat=rotate_mat, rotate_mat_cur=rotate_mat_cur, size=size)
        center_embed = self.out_proj(propagate_res)
        return self.proj_drop(center_embed), nbr_embed

    def _ff_block(self, x: torch.Tensor) -> torch.Tensor:
        return self.mlp(x)

    def expand_left(self, src: torch.Tensor, dim: int, dims: int) -> torch.Tensor:
        for _ in range(dims + dim if dim < 0 else dim):
            src = src.unsqueeze(0)
        return src


class TemporalEncoder(nn.Module):

    def __init__(self,
                 historical_steps: int,
                 embed_dim: int,
                 num_heads: int = 8,
                 num_layers: int = 4,
                 dropout: float = 0.1) -> None:
        super(TemporalEncoder, self).__init__()
        encoder_layer = TemporalEncoderLayer(embed_dim=embed_dim, num_heads=num_heads, dropout=dropout)
        self.transformer_encoder = TransformerEncoder(encoder_layer=encoder_layer, num_layers=num_layers,
                                                         norm=nn.LayerNorm(embed_dim))
        self.padding_token = nn.Parameter(torch.Tensor(historical_steps, 1, embed_dim))
        self.cls_token = nn.Parameter(torch.Tensor(1, 1, embed_dim))
        self.pos_embed = nn.Parameter(torch.Tensor(historical_steps + 1, 1, embed_dim))
        # attn_mask = self.generate_square_subsequent_mask(historical_steps + 1)
        attn_mask, self.attn_mask_bool = self.generate_square_subsequent_mask(historical_steps + 1)
        self.register_buffer('attn_mask', attn_mask)
        nn.init.normal_(self.padding_token, mean=0., std=.02)
        nn.init.normal_(self.cls_token, mean=0., std=.02)
        nn.init.normal_(self.pos_embed, mean=0., std=.02)
        self.apply(init_weights)

    def forward(self,
                x: torch.Tensor,
                padding_mask: torch.Tensor) -> torch.Tensor:
        x = torch.where(padding_mask.t().unsqueeze(-1), self.padding_token, x)
        expand_cls_token = self.cls_token.expand(-1, x.shape[1], -1)
        # x = torch.cat((x, expand_cls_token), dim=0)
        x = torch.cat((expand_cls_token, x), dim=0)
        x = x + self.pos_embed
        device = x.device
        cls_padding = torch.zeros((x.shape[1], 1), dtype=torch.bool, device=device)
        padding = torch.cat((cls_padding, padding_mask), dim=-1)
        head_dim = 8  # num_head = 8
        matrix = torch.ones_like(padding, dtype=torch.float32)
        matrix = matrix.masked_fill(padding, 0)
        matrix1 = matrix.unsqueeze(-1)
        matrix2 = matrix.unsqueeze(-2)
        matrix = torch.matmul(matrix1, matrix2).to(torch.int32)
        a = self.attn_mask_bool.unsqueeze(0).repeat(x.shape[1], 1, 1).int().to(device)
        matrix_result = (matrix & a).bool()
        matrix_tmp = torch.full(matrix.shape, float(-1e12)).to(device)
        matrix_result = matrix_tmp.masked_fill(matrix_result, float(0))
        matrix_result = torch.repeat_interleave(matrix_result, repeats=head_dim, dim=0)
        out = self.transformer_encoder(src=x, mask=matrix_result, src_key_padding_mask=None)
        # out = self.transformer_encoder(src=x, mask=self.attn_mask, src_key_padding_mask=None)
        return out[-1]  # [N, D]

    @staticmethod
    def generate_square_subsequent_mask(seq_len: int) -> torch.Tensor:
        mask = (torch.triu(torch.ones(seq_len, seq_len)) == 1).transpose(0, 1)
        mask1 = mask
        mask = mask.float().masked_fill(mask == 0, float('-inf')).masked_fill(mask == 1, float(0.0))
        return mask, mask1


class TemporalEncoderLayer(nn.Module):

    def __init__(self,
                 embed_dim: int,
                 num_heads: int = 8,
                 dropout: float = 0.1) -> None:
        super(TemporalEncoderLayer, self).__init__()
        self.self_attn = nn.MultiheadAttention(embed_dim=embed_dim, num_heads=num_heads, dropout=dropout)
        self.linear1 = nn.Linear(embed_dim, embed_dim * 4)
        self.dropout = nn.Dropout(dropout)
        self.linear2 = nn.Linear(embed_dim * 4, embed_dim)
        self.norm1 = nn.LayerNorm(embed_dim)
        self.norm2 = nn.LayerNorm(embed_dim)
        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)

    def forward(self,
                src: torch.Tensor,
                src_mask: Optional[torch.Tensor] = None,
                src_key_padding_mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        x = src
        x = x + self._sa_block(self.norm1(x), src_mask, src_key_padding_mask)
        x = x + self._ff_block(self.norm2(x))
        return x

    def _sa_block(self,
                  x: torch.Tensor,
                  attn_mask: Optional[torch.Tensor],
                  key_padding_mask: Optional[torch.Tensor]) -> torch.Tensor:
        x = self.self_attn(x, x, x, attn_mask=attn_mask, key_padding_mask=key_padding_mask, need_weights=False)[0]
        return self.dropout1(x)

    def _ff_block(self, x: torch.Tensor) -> torch.Tensor:
        x = self.linear2(self.dropout(F.relu_(self.linear1(x))))
        return self.dropout2(x)


class ALEncoder(MessagePassing):

    def __init__(self,
                 node_dim: int,
                 edge_dim: int,
                 embed_dim: int,
                 speed_limit_dim: int = 1,
                 num_heads: int = 8,
                 dropout: float = 0.1,
                 **kwargs) -> None:
        super(ALEncoder, self).__init__(aggr='add', node_dim=0, **kwargs)
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.lane_embed_ego = LaneEmbedding(out_channel=embed_dim)
        self.lane_embed_agent = LaneEmbedding(out_channel=embed_dim)
        self.lane_embed = PointsEncoder(feat_channel=node_dim + edge_dim, encoder_channel=embed_dim)
        self.speed_limit_emb = nn.Sequential(nn.Linear(1, embed_dim), nn.ReLU(), nn.Linear(embed_dim, embed_dim))
        self.lin_q = nn.Linear(embed_dim, embed_dim)
        self.lin_k = nn.Linear(embed_dim, embed_dim)
        self.lin_v = nn.Linear(embed_dim, embed_dim)
        self.lin_self = nn.Linear(embed_dim, embed_dim)
        self.attn_drop = nn.Dropout(dropout)
        self.lin_ih = nn.Linear(embed_dim, embed_dim)
        self.lin_hh = nn.Linear(embed_dim, embed_dim)
        self.out_proj = nn.Linear(embed_dim, embed_dim)
        self.proj_drop = nn.Dropout(dropout)
        self.norm1 = nn.LayerNorm(embed_dim)
        self.norm2 = nn.LayerNorm(embed_dim)
        self.mlp = nn.Sequential(
            nn.Linear(embed_dim, embed_dim * 4),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(embed_dim * 4, embed_dim),
            nn.Dropout(dropout))
        self.lane_type_embed = nn.Parameter(torch.Tensor(3, embed_dim))
        self.lane_on_route_embed = nn.Parameter(torch.Tensor(2, embed_dim))
        self.lane_tl_status_embed = nn.Parameter(torch.Tensor(4, embed_dim))
        self.unknown_speed_embed = nn.Parameter(torch.Tensor(1, embed_dim))
        nn.init.normal_(self.lane_type_embed, mean=0., std=.02)
        nn.init.normal_(self.lane_on_route_embed, mean=0., std=.02)
        nn.init.normal_(self.lane_tl_status_embed, mean=0., std=.02)
        nn.init.normal_(self.unknown_speed_embed, mean=0., std=.02)
        self.apply(init_weights)

    def forward(self,
                x: Tuple[torch.Tensor, torch.Tensor],
                edge_index: Adj,
                edge_attr: torch.Tensor,
                positions: torch.Tensor,
                lane_positions: torch.Tensor,
                lane_types: torch.Tensor,
                lane_on_route: torch.Tensor,
                lane_tl_status: torch.Tensor,
                lane_has_speed_limit: torch.Tensor,
                lane_speed_limit: torch.Tensor,
                lane_valid_mask: torch.Tensor,
                edge_v_attr: Optional[torch.Tensor] = None,
                edge_heading_attr: Optional[torch.Tensor] = None,
                rotate_mat: Optional[torch.Tensor] = None,
                av_index: Optional[torch.Tensor] = None,
                size: Size = None) -> Tuple[torch.Tensor, torch.Tensor]:
        x_lane, x_actor = x
        lane_types = lane_types.long()
        lane_on_route = lane_on_route.long()
        lane_tl_status = lane_tl_status.long()
        lane_has_speed_limit = lane_has_speed_limit.bool()
        mha_block_res, nbr_embed = self._mha_block(self.norm1(x_actor), x_lane, edge_index, edge_attr, positions,
                                                   lane_positions, edge_v_attr, edge_heading_attr, lane_types,
                                                   lane_on_route, lane_tl_status, lane_has_speed_limit, lane_speed_limit,
                                                   lane_valid_mask, rotate_mat, av_index, size)
        x_actor = x_actor + mha_block_res
        x_actor = x_actor + self._ff_block(self.norm2(x_actor))
        return x_actor

    def message(self,
                edge_index: Adj,
                x_i: torch.Tensor,
                x_j: torch.Tensor,
                edge_attr: torch.Tensor,
                positions_i: torch.Tensor,
                lane_positions_j: torch.Tensor,
                edge_v_attr: torch.Tensor,
                edge_heading_attr: torch.Tensor,
                lane_types_j: torch.Tensor,
                lane_on_route_j: torch.Tensor,
                lane_tl_status_j: torch.Tensor,
                lane_has_speed_limit_j: torch.Tensor,
                lane_speed_limit_j: torch.Tensor,
                lane_valid_mask_j: torch.Tensor,
                rotate_mat: Optional[torch.Tensor],
                av: Optional[torch.Tensor],
                index: torch.Tensor,
                ptr: OptTensor,
                size_i: Optional[int]) -> Tuple[torch.Tensor, torch.Tensor]:
        device = x_j.device
        rotate_mat = rotate_mat[edge_index[1]]
        av_mask = (index == av[:, None]).any(dim=0)
        lane_embed = self.lane_embed(torch.cat((torch.bmm(x_j, rotate_mat),
                                     torch.bmm(lane_positions_j - positions_i.unsqueeze(1), rotate_mat)), dim=-1),
                                     lane_valid_mask_j)
        x_speed_limit = torch.zeros(lane_speed_limit_j.shape[0], self.embed_dim, device=device)
        x_speed_limit[lane_has_speed_limit_j] = self.speed_limit_emb(
            lane_speed_limit_j[lane_has_speed_limit_j].unsqueeze(-1)
        )
        x_speed_limit[~lane_has_speed_limit_j] = self.unknown_speed_embed
        x_j_new = torch.zeros(x_j.shape[0], self.embed_dim)
        x_j_new = x_j_new.to(device)
        x_j_new[av_mask] = self.lane_embed_ego([lane_embed[av_mask],
                                                self.lane_type_embed[lane_types_j[av_mask].squeeze()],
                                                self.lane_on_route_embed[lane_on_route_j[av_mask].squeeze()],
                                                self.lane_tl_status_embed[lane_tl_status_j[av_mask].squeeze()],
                                                x_speed_limit[av_mask]])
        x_j_new[~av_mask] = self.lane_embed_agent([lane_embed[~av_mask],
                                                   self.lane_type_embed[lane_types_j[~av_mask].squeeze()],
                                                   self.lane_tl_status_embed[lane_tl_status_j[~av_mask].squeeze()],
                                                   x_speed_limit[~av_mask]])
        query = self.lin_q(x_i).view(-1, self.num_heads, self.embed_dim // self.num_heads)
        key = self.lin_k(x_j_new).view(-1, self.num_heads, self.embed_dim // self.num_heads)
        value = self.lin_v(x_j_new).view(-1, self.num_heads, self.embed_dim // self.num_heads)
        scale = (self.embed_dim // self.num_heads) ** 0.5
        alpha = (query * key).sum(dim=-1) / scale
        alpha = softmax(alpha, index, ptr, size_i)
        alpha = self.attn_drop(alpha)
        return value * alpha.unsqueeze(-1), x_j_new

    def aggregate(self, inputs: torch.Tensor, index: torch.Tensor,
                  ptr: Optional[torch.Tensor] = None,
                  dim_size: Optional[int] = None) -> Tuple[torch.Tensor, torch.Tensor]:
        r"""Aggregates messages from neighbors as
        :math:`\square_{j \in \mathcal{N}(i)}`.

        Takes in the output of message computation as first argument and any
        argument which was initially passed to :meth:`propagate`.

        By default, this function will delegate its call to scatter functions
        that support "add", "mean" and "max" operations as specified in
        :meth:`__init__` by the :obj:`aggr` argument.
        """
        agg_inputs, nbr_embed = inputs
        if ptr is not None:
            ptr = self.expand_left(ptr, dim=self.node_dim, dims=agg_inputs.dim())
            return segment_csr(agg_inputs, ptr, reduce=self.aggr), nbr_embed
        else:
            return scatter(agg_inputs, index, dim=self.node_dim, dim_size=dim_size,
                           reduce=self.aggr), nbr_embed

    def update(self,
               inputs: torch.Tensor,
               x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        upd_inputs, nbr_embed = inputs
        x_actor = x[1]
        upd_inputs = upd_inputs.view(-1, self.embed_dim)
        gate = torch.sigmoid(self.lin_ih(upd_inputs) + self.lin_hh(x_actor))
        return upd_inputs + gate * (self.lin_self(x_actor) - upd_inputs), nbr_embed

    def _mha_block(self,
                   x_actor: torch.Tensor,
                   x_lane: torch.Tensor,
                   edge_index: Adj,
                   edge_attr: torch.Tensor,
                   positions: torch.Tensor,
                   lane_positions: torch.Tensor,
                   edge_v_attr: torch.Tensor,
                   edge_heading_attr: torch.Tensor,
                   lane_types: torch.Tensor,
                   lane_on_route: torch.Tensor,
                   lane_tl_status: torch.Tensor,
                   lane_has_speed_limit: torch.Tensor,
                   lane_speed_limit: torch.Tensor,
                   lane_valid_mask: torch.Tensor,
                   rotate_mat: Optional[torch.Tensor],
                   av: Optional[torch.Tensor],
                   size: Size) -> Tuple[torch.Tensor, torch.Tensor]:
        propagate_res, nbr_embed = self.propagate(edge_index=edge_index, x=(x_lane, x_actor), edge_attr=edge_attr,
                                                  positions=positions,
                                                  lane_positions=lane_positions, edge_v_attr=edge_v_attr,
                                                  edge_heading_attr=edge_heading_attr,
                                                  lane_types=lane_types, lane_on_route=lane_on_route,
                                                  lane_tl_status=lane_tl_status,
                                                  lane_has_speed_limit=lane_has_speed_limit,
                                                  lane_speed_limit=lane_speed_limit,
                                                  lane_valid_mask=lane_valid_mask,
                                                  rotate_mat=rotate_mat, av=av, size=size)
        x_actor = self.out_proj(propagate_res)
        return self.proj_drop(x_actor), nbr_embed

    def _ff_block(self, x_actor: torch.Tensor) -> torch.Tensor:
        return self.mlp(x_actor)

    def expand_left(self, src: torch.Tensor, dim: int, dims: int) -> torch.Tensor:
        for _ in range(dims + dim if dim < 0 else dim):
            src = src.unsqueeze(0)
        return src