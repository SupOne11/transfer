import math
import torch
import torch.nn as nn
import torch.nn.functional as F


class ScoreDecoder(nn.Module):
    def __init__(self, variable_cost=False):
        super(ScoreDecoder, self).__init__()
        self._n_latent_features = 4
        self._variable_cost = variable_cost

        self.interaction_feature_encoder = nn.Sequential(nn.Linear(10, 64), nn.ReLU(), nn.Linear(64, 128))
        self.interaction_feature_decoder = nn.Sequential(nn.Linear(128, 64), nn.ELU(),
                                                         nn.Linear(64, self._n_latent_features), nn.Sigmoid())
        self.weights_decoder = nn.Sequential(nn.Linear(128, 64), nn.ELU(), nn.Linear(64, self._n_latent_features + 4),
                                             nn.Softplus())

    def get_hardcoded_features(self, ego_traj):
        # ego_traj: B, M, T, 6
        # x, y, yaw, v, a, r

        speed = ego_traj[:, :, :, 3]  # [B, M, T]
        acceleration = ego_traj[:, :, :, 4]
        jerk = torch.diff(acceleration, dim=-1) / 0.1
        jerk = torch.cat((jerk[:, :, :1], jerk), dim=-1)
        curvature = ego_traj[:, :, :, 5]
        lateral_acceleration = speed ** 2 * curvature

        speed = -speed.mean(-1).clip(0, 15) / 15  # 取平均后归一化[B, M]
        acceleration = acceleration.abs().mean(-1).clip(0, 4) / 4
        jerk = jerk.abs().mean(-1).clip(0, 6) / 6
        lateral_acceleration = lateral_acceleration.abs().mean(-1).clip(0, 5) / 5

        features = torch.stack((speed, acceleration, jerk, lateral_acceleration), dim=-1)  # [B, M, 4]

        return features

    def calculate_collision(self, ego_traj, agent_traj):
        # ego_traj: T, 3
        # agent_traj: N, T, 3

        # Compute the distance between the two agents
        dist = torch.norm(ego_traj[None, :, :2] - agent_traj[:, :, :2], dim=-1)  # [N T]

        # Compute the collision cost
        cost = torch.exp(-0.2 * dist ** 2)
        cost = cost.sum(-1).sum(-1)

        return cost

    def get_latent_interaction_features(self, ego_traj, agent_traj, agents_states):
        # ego_traj: B, T, 6
        # agent_traj: B, N, T, 3
        # agents_states: B, N, 11

        # Get relative attributes of agents
        relative_yaw = agent_traj[:, :, 2] - ego_traj[None, :, 2]  # 每一时刻ego与agent的夹角
        relative_yaw = torch.atan2(torch.sin(relative_yaw), torch.cos(relative_yaw))
        relative_pos = agent_traj[:, :, :2] - ego_traj[None, :, :2]  # 全局坐标系内ego与agent的相对位置
        relative_pos = torch.stack([relative_pos[..., 0] * torch.cos(relative_yaw),
                                    relative_pos[..., 1] * torch.sin(relative_yaw)], dim=-1)  # 转到ego当前坐标系
        agent_velocity = torch.diff(agent_traj[:, :, :2], dim=-2) / 0.1  # 计算agent全局坐标系下的速度
        agent_velocity = torch.cat((agent_velocity[:, :1, :], agent_velocity), dim=-2)
        ego_velocity_x = ego_traj[:, 3] * torch.cos(ego_traj[:, 2])  # 全局坐标系下ego速度矢量
        ego_velocity_y = ego_traj[:, 3] * torch.sin(ego_traj[:, 2])
        relative_velocity = torch.stack([(agent_velocity[..., 0] - ego_velocity_x) * torch.cos(relative_yaw),
                                         (agent_velocity[..., 1] - ego_velocity_y) * torch.sin(relative_yaw)],
                                        dim=-1)  # ego当前坐标系相对速度矢量[N, T, 2]
        relative_attributes = torch.cat((relative_pos, relative_yaw.unsqueeze(-1), relative_velocity), dim=-1)

        # Get agent attributes
        agent_attributes = agents_states.unsqueeze(1).expand(-1, relative_attributes.shape[1], -1)
        attributes = torch.cat((relative_attributes, agent_attributes), dim=-1)

        # Encode relative attributes and decode to latent interaction features
        features = self.interaction_feature_encoder(attributes)
        features = features.max(0).values.mean(0)
        features = self.interaction_feature_decoder(features)

        return features

    def forward(self, ego_traj, ego_encoding, agents_traj, data, agent_index):
        """
        Parameters
        ----------
        ego_traj       [B, M, T, 6]       ->      [M, B, T, 2] 缺少航向角，速度，加速度，曲率
        ego_encoding   [B, D]
        agents_traj    [B, M, N, T, 3]    ->      [B*N, T, 2] 缺少航向角，模态
        agents_states  [B, N, 11]
        Returns
        -------
        """
        ego_traj = ego_traj.transpose(0, 1)

        start_point = torch.zeros(ego_traj.shape[0], ego_traj.shape[1], 1, ego_traj.shape[3], device=ego_traj.device)
        extended_ego = torch.cat((start_point, ego_traj), dim=2)
        # Calculating the position differences relative to (0,0)
        ego_pos = extended_ego[:, :, 1:, :] - extended_ego[:, :, :-1, :]
        # Calculating headings
        headings_ego = torch.atan2(ego_pos[..., 1], ego_pos[..., 0])
        # Convert range from [-pi, pi] to [0, 2pi]
        headings_ego = (headings_ego + 2 * torch.pi) % (2 * torch.pi)

        start_agents = data['positions'][agent_index, 19, :]
        extended_agent = torch.cat((start_agents.view(-1, 1, 2), agents_traj), dim=1)
        agent_pos = extended_agent[:, 1:, :] - extended_agent[:, :-1, :]
        headings_agent = torch.atan2(agent_pos[..., 1], agent_pos[..., 0])
        headings_agent = (headings_agent + 2 * torch.pi) % (2 * torch.pi)
        agents = torch.cat((agents_traj, headings_agent.view(-1, 80, 1)), dim=-1)
        # 初始化一个空的字典来存储轨迹
        cls_one_hot = torch.nn.functional.one_hot(data['cls'][agent_index].long() - 1, num_classes=3)
        attr = torch.cat((data['shape'][agent_index], cls_one_hot), dim=1)
        traj_dict = {}
        attr_dict = {}
        # 遍历每个智能体的轨迹，并将其分配到相应的批次中
        for i, b in enumerate(data['batch']):
            if b.item() not in traj_dict:
                traj_dict[b.item()] = []
                attr_dict[b.item()] = []
            if i not in data['av_index']:
                # 使用一个新的索引来跳过自车的轨迹
                agent_idx = i - sum(i > data['av_index'])
                traj_dict[b.item()].append(agents[agent_idx])
                attr_dict[b.item()].append(attr[agent_idx])
        # 将字典的值转换为列表格式
        agent_list = [torch.stack(traj_dict[k]) for k in sorted(traj_dict.keys())]
        attr_list = [torch.stack(attr_dict[k]) for k in sorted(attr_dict.keys())]
        velocities = extended_ego[:, :, 1:, :] - extended_ego[:, :, :-1, :]
        # Calculating speeds (norm of velocities)
        speeds = torch.norm(velocities, dim=-1)

        # Calculating accelerations
        accelerations = torch.zeros_like(velocities)
        accelerations[:, :, 1:, :] = velocities[:, :, 1:, :] - velocities[:, :, :-1, :]
        accelerations[:, :, 0, :] = accelerations[:, :, 1, :]
        # Calculating acceleration magnitudes
        accel_magnitudes = torch.norm(accelerations, dim=-1)

        # Calculating jerks (rate of change of acceleration)
        jerks = torch.zeros_like(velocities)
        jerks[:, :, 1:, :] = accelerations[:, :, 1:, :] - accelerations[:, :, :-1, :]
        jerks[:, :, 0, :] = jerks[:, :, 1, :]
        # Calculating jerk magnitudes
        jerk_magnitudes = torch.norm(jerks, dim=-1)

        # Calculating pseudo-cross product for 2D vectors
        pseudo_cross_product = velocities[:, :, :, 0] * accelerations[:, :, :, 1] - velocities[:, :, :, 1] * accelerations[:, :, :, 0]
        curvature = torch.abs(pseudo_cross_product) / (speeds[:, :, :] ** 3 + 1e-8)
        ego = torch.cat((ego_traj, headings_ego.unsqueeze(-1), speeds.unsqueeze(-1), accel_magnitudes.unsqueeze(-1),
                         jerk_magnitudes.unsqueeze(-1)), dim=-1)

        ego_traj_features = self.get_hardcoded_features(ego)

        agents_states = []
        if not self._variable_cost:
            ego_encoding = torch.ones_like(ego_encoding)  # weights的取值与不同场景无关
        weights = self.weights_decoder(ego_encoding)

        scores = []
        # 遍历不同的mod
        for i in range(ego.shape[1]):
            hardcoded_features = ego_traj_features[:, i]
            interaction_features = torch.zeros((ego.shape[0], 4), device=ego.device)
            collision_feature = torch.zeros((ego.shape[0]), device=ego.device)
            for j in range(ego.shape[0]):
                interaction_features[j] = self.get_latent_interaction_features(ego[j, i], agent_list[j], attr_list[j])
                collision_feature[j] = self.calculate_collision(ego[j, i], agent_list[j])
            features = torch.cat((hardcoded_features, interaction_features), dim=-1)
            score = -torch.sum(features * weights, dim=-1)
            score += -10 * collision_feature
            scores.append(score)

        scores = torch.stack(scores, dim=1)

        return scores, weights