# Copyright (c) 2022, Zikang Zhou. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from typing import Optional, Tuple, Any
from typing import Optional, Tuple

from typing import Optional, Tuple

import torch
import torch.nn as nn

from torch_geometric.nn.conv import MessagePassing
from torch_geometric.typing import Adj
from torch_geometric.typing import OptTensor
from torch_geometric.typing import Size
from torch_geometric.utils import softmax
from torch_scatter import scatter, segment_csr
from models import MultipleInputEmbedding, PointsEncoder, LaneEmbedding
from utils import DistanceDropEdge
from utils import TemporalData
from utils import init_weights


class FutureEncoder(nn.Module):

    def __init__(self,
                 node_dim: int,
                 edge_dim: int,
                 embed_dim: int,
                 num_heads: int = 8,
                 dropout: float = 0.1,
                 local_radius: float = 50) -> None:
        super(FutureEncoder, self).__init__()
        self.al_encoder = ALEncoder(node_dim=node_dim,
                                    edge_dim=edge_dim,
                                    embed_dim=embed_dim,
                                    num_heads=num_heads,
                                    dropout=dropout)
        self.drop_edge = DistanceDropEdge(local_radius)
        self.apply(init_weights)

    def forward(self,
                data: TemporalData,
                lane_actor_index_future: torch.Tensor,
                lane_actor_vectors_future: torch.Tensor,
                x: torch.Tensor):
        self.attention_scores = None
        edge_index, edge_attr = self.drop_edge(lane_actor_index_future, lane_actor_vectors_future)
        out = self.al_encoder(x=(data['lane_vectors'], x),
                              edge_index=edge_index,
                              edge_attr=edge_attr,
                              positions=data['positions'][:, 19],
                              lane_positions=data['lane_positions'],
                              lane_types=data['lane_types'],
                              lane_on_route=data['lane_on_route'],
                              lane_tl_status=data['lane_tl_status'],
                              lane_has_speed_limit=data['lane_has_speed_limit'],
                              lane_speed_limit=data['lane_speed_limit'],
                              lane_valid_mask=data['lane_valid_mask'],
                              rotate_mat=data['rotate_mat'],
                              av_index=data['av_index'])
        return out


class ALEncoder(MessagePassing):

    def __init__(self,
                 node_dim: int,
                 edge_dim: int,
                 embed_dim: int,
                 speed_limit_dim: int = 1,
                 num_heads: int = 8,
                 dropout: float = 0.1,
                 **kwargs) -> None:
        super(ALEncoder, self).__init__(aggr='add', node_dim=0, **kwargs)
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.lane_embed_ego = LaneEmbedding(out_channel=embed_dim)
        self.lane_embed_agent = LaneEmbedding(out_channel=embed_dim)
        self.lane_embed = PointsEncoder(feat_channel=node_dim + edge_dim, encoder_channel=embed_dim)
        self.speed_limit_emb = nn.Sequential(nn.Linear(1, embed_dim), nn.ReLU(), nn.Linear(embed_dim, embed_dim))
        self.lin_q = nn.Linear(embed_dim, embed_dim)
        self.lin_k = nn.Linear(embed_dim, embed_dim)
        self.lin_v = nn.Linear(embed_dim, embed_dim)
        self.lin_self = nn.Linear(embed_dim, embed_dim)
        self.attn_drop = nn.Dropout(dropout)
        self.lin_ih = nn.Linear(embed_dim, embed_dim)
        self.lin_hh = nn.Linear(embed_dim, embed_dim)
        self.out_proj = nn.Linear(embed_dim, embed_dim)
        self.proj_drop = nn.Dropout(dropout)
        self.norm1 = nn.LayerNorm(embed_dim)
        self.norm2 = nn.LayerNorm(embed_dim)
        self.mlp = nn.Sequential(
            nn.Linear(embed_dim, embed_dim * 4),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(embed_dim * 4, embed_dim),
            nn.Dropout(dropout))
        self.lane_type_embed = nn.Parameter(torch.Tensor(3, embed_dim))
        self.lane_on_route_embed = nn.Parameter(torch.Tensor(2, embed_dim))
        self.lane_tl_status_embed = nn.Parameter(torch.Tensor(4, embed_dim))
        self.unknown_speed_embed = nn.Parameter(torch.Tensor(1, embed_dim))
        nn.init.normal_(self.lane_type_embed, mean=0., std=.02)
        nn.init.normal_(self.lane_on_route_embed, mean=0., std=.02)
        nn.init.normal_(self.lane_tl_status_embed, mean=0., std=.02)
        nn.init.normal_(self.unknown_speed_embed, mean=0., std=.02)
        self.apply(init_weights)

    def forward(self,
                x: Tuple[torch.Tensor, torch.Tensor],
                edge_index: Adj,
                edge_attr: torch.Tensor,
                positions: torch.Tensor,
                lane_positions: torch.Tensor,
                lane_types: torch.Tensor,
                lane_on_route: torch.Tensor,
                lane_tl_status: torch.Tensor,
                lane_has_speed_limit: torch.Tensor,
                lane_speed_limit: torch.Tensor,
                lane_valid_mask: torch.Tensor,
                edge_v_attr: Optional[torch.Tensor] = None,
                edge_heading_attr: Optional[torch.Tensor] = None,
                rotate_mat: Optional[torch.Tensor] = None,
                av_index: Optional[torch.Tensor] = None,
                size: Size = None) -> Tuple[torch.Tensor, torch.Tensor]:
        x_lane, x_actor = x
        lane_types = lane_types.long()
        lane_on_route = lane_on_route.long()
        lane_tl_status = lane_tl_status.long()
        lane_has_speed_limit = lane_has_speed_limit.bool()
        if edge_index.numel() == 0:
            mha_block_res = torch.zeros_like(x_actor)
        else:
            mha_block_res, nbr_embed = self._mha_block(self.norm1(x_actor), x_lane, edge_index, edge_attr, positions,
                                                       lane_positions, edge_v_attr, edge_heading_attr, lane_types,
                                                       lane_on_route, lane_tl_status, lane_has_speed_limit, lane_speed_limit,
                                                       lane_valid_mask, rotate_mat, av_index, size)
        x_actor = x_actor + mha_block_res
        x_actor = x_actor + self._ff_block(self.norm2(x_actor))
        return x_actor

    def message(self,
                edge_index: Adj,
                x_i: torch.Tensor,
                x_j: torch.Tensor,
                edge_attr: torch.Tensor,
                positions_i: torch.Tensor,
                lane_positions_j: torch.Tensor,
                edge_v_attr: torch.Tensor,
                edge_heading_attr: torch.Tensor,
                lane_types_j: torch.Tensor,
                lane_on_route_j: torch.Tensor,
                lane_tl_status_j: torch.Tensor,
                lane_has_speed_limit_j: torch.Tensor,
                lane_speed_limit_j: torch.Tensor,
                lane_valid_mask_j: torch.Tensor,
                rotate_mat: Optional[torch.Tensor],
                av: Optional[torch.Tensor],
                index: torch.Tensor,
                ptr: OptTensor,
                size_i: Optional[int]) -> Tuple[torch.Tensor, torch.Tensor]:
        device = x_j.device
        rotate_mat = rotate_mat[edge_index[1]]
        av_mask = (index == av[:, None]).any(dim=0)
        lane_embed = self.lane_embed(torch.cat((torch.bmm(x_j, rotate_mat),
                                     torch.bmm(lane_positions_j - positions_i.unsqueeze(1), rotate_mat)), dim=-1),
                                     lane_valid_mask_j)
        x_speed_limit = torch.zeros(lane_speed_limit_j.shape[0], self.embed_dim, device=device)
        x_speed_limit[lane_has_speed_limit_j] = self.speed_limit_emb(
            lane_speed_limit_j[lane_has_speed_limit_j].unsqueeze(-1)
        )
        x_speed_limit[~lane_has_speed_limit_j] = self.unknown_speed_embed
        x_j_new = torch.zeros(x_j.shape[0], self.embed_dim)
        x_j_new = x_j_new.to(device)
        x_j_new[av_mask] = self.lane_embed_ego([lane_embed[av_mask],
                                                self.lane_type_embed[lane_types_j[av_mask].squeeze()],
                                                self.lane_on_route_embed[lane_on_route_j[av_mask].squeeze()],
                                                self.lane_tl_status_embed[lane_tl_status_j[av_mask].squeeze()],
                                                x_speed_limit[av_mask]])
        x_j_new[~av_mask] = self.lane_embed_agent([lane_embed[~av_mask],
                                                   self.lane_type_embed[lane_types_j[~av_mask].squeeze()],
                                                   self.lane_tl_status_embed[lane_tl_status_j[~av_mask].squeeze()],
                                                   x_speed_limit[~av_mask]])
        query = self.lin_q(x_i).view(-1, self.num_heads, self.embed_dim // self.num_heads)
        key = self.lin_k(x_j_new).view(-1, self.num_heads, self.embed_dim // self.num_heads)
        value = self.lin_v(x_j_new).view(-1, self.num_heads, self.embed_dim // self.num_heads)
        scale = (self.embed_dim // self.num_heads) ** 0.5
        alpha = (query * key).sum(dim=-1) / scale
        alpha = softmax(alpha, index, ptr, size_i)
        alpha = self.attn_drop(alpha)
        return value * alpha.unsqueeze(-1), x_j_new

    def aggregate(self, inputs: torch.Tensor, index: torch.Tensor,
                  ptr: Optional[torch.Tensor] = None,
                  dim_size: Optional[int] = None) -> Tuple[torch.Tensor, torch.Tensor]:
        r"""Aggregates messages from neighbors as
        :math:`\square_{j \in \mathcal{N}(i)}`.

        Takes in the output of message computation as first argument and any
        argument which was initially passed to :meth:`propagate`.

        By default, this function will delegate its call to scatter functions
        that support "add", "mean" and "max" operations as specified in
        :meth:`__init__` by the :obj:`aggr` argument.
        """
        agg_inputs, nbr_embed = inputs
        if ptr is not None:
            ptr = self.expand_left(ptr, dim=self.node_dim, dims=agg_inputs.dim())
            return segment_csr(agg_inputs, ptr, reduce=self.aggr), nbr_embed
        else:
            return scatter(agg_inputs, index, dim=self.node_dim, dim_size=dim_size,
                           reduce=self.aggr), nbr_embed

    def update(self,
               inputs: torch.Tensor,
               x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        upd_inputs, nbr_embed = inputs
        x_actor = x[1]
        upd_inputs = upd_inputs.view(-1, self.embed_dim)
        gate = torch.sigmoid(self.lin_ih(upd_inputs) + self.lin_hh(x_actor))
        return upd_inputs + gate * (self.lin_self(x_actor) - upd_inputs), nbr_embed

    def _mha_block(self,
                   x_actor: torch.Tensor,
                   x_lane: torch.Tensor,
                   edge_index: Adj,
                   edge_attr: torch.Tensor,
                   positions: torch.Tensor,
                   lane_positions: torch.Tensor,
                   edge_v_attr: torch.Tensor,
                   edge_heading_attr: torch.Tensor,
                   lane_types: torch.Tensor,
                   lane_on_route: torch.Tensor,
                   lane_tl_status: torch.Tensor,
                   lane_has_speed_limit: torch.Tensor,
                   lane_speed_limit: torch.Tensor,
                   lane_valid_mask: torch.Tensor,
                   rotate_mat: Optional[torch.Tensor],
                   av: Optional[torch.Tensor],
                   size: Size) -> Tuple[torch.Tensor, torch.Tensor]:
        propagate_res, nbr_embed = self.propagate(edge_index=edge_index, x=(x_lane, x_actor), edge_attr=edge_attr,
                                                  positions=positions,
                                                  lane_positions=lane_positions, edge_v_attr=edge_v_attr,
                                                  edge_heading_attr=edge_heading_attr,
                                                  lane_types=lane_types, lane_on_route=lane_on_route,
                                                  lane_tl_status=lane_tl_status,
                                                  lane_has_speed_limit=lane_has_speed_limit,
                                                  lane_speed_limit=lane_speed_limit,
                                                  lane_valid_mask=lane_valid_mask,
                                                  rotate_mat=rotate_mat, av=av, size=size)
        x_actor = self.out_proj(propagate_res)
        return self.proj_drop(x_actor), nbr_embed

    def _ff_block(self, x_actor: torch.Tensor) -> torch.Tensor:
        return self.mlp(x_actor)

    def expand_left(self, src: torch.Tensor, dim: int, dims: int) -> torch.Tensor:
        for _ in range(dims + dim if dim < 0 else dim):
            src = src.unsqueeze(0)
        return src