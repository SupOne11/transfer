import torch

# # 假设a是一个已经存在的tensor，其形状为[2, N]
# a = torch.tensor([[1, 2, 4, 5, 7], [0, 3, 0, 6, 3]])
#
# # d是目标节点的索引数组
# d = torch.tensor([0, 3])
#
# # 使用广播机制来找出所有目标节点为d中任意一个的边
# # 这里 `a[1]` 直接取第二行，即所有的目标节点，并增加一个维度用于广播
# target_in_d = (a[1] == d[:, None]).any(dim=0)
#
# # 保存目标节点在d中的边
# b = a[:, target_in_d]
#
# # 保存目标节点不在d中的边
# c = a[:, ~target_in_d]
#
# print("目标节点在d中的边 b:", b)
# print("剩余的边 c:", c)

a = torch.tensor([[0, 0], [1, 1], [2, 2], [3, 3]])
b = torch.tensor([0, 2])
c = a[b]
print(c)
